package com.alumni.searcher.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class AlumniSearchRequest {

    @NotBlank(message = "university is required")
    private String university;

    @NotBlank(message = "designation is required")
    private String designation;

    @Min(value = 1950, message = "passoutYear looks too old")
    @Max(value = 2100, message = "passoutYear looks too far in the future")
    private Integer passoutYear;

    public AlumniSearchRequest() {
    }

    public AlumniSearchRequest(String university, String designation, Integer passoutYear) {
        this.university = university;
        this.designation = designation;
        this.passoutYear = passoutYear;
    }

    public String getUniversity() { return university; }
    public void setUniversity(String university) { this.university = university; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public Integer getPassoutYear() { return passoutYear; }
    public void setPassoutYear(Integer passoutYear) { this.passoutYear = passoutYear; }
}
