package com.alumni.searcher.dto;

public record AlumniDto(
        String name,
        String currentRole,
        String university,
        String location,
        String linkedinHeadline,
        Integer passoutYear) {
}
