package com.alumni.searcher.service;

import com.alumni.searcher.dto.AlumniDto;
import com.alumni.searcher.dto.AlumniSearchRequest;
import com.alumni.searcher.entity.Alumni;
import com.alumni.searcher.repository.AlumniRepository;
import com.alumni.searcher.scraper.ProfileScraper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class AlumniService {

    private final ProfileScraper scraper;
    private final AlumniRepository repository;

    public AlumniService(ProfileScraper scraper, AlumniRepository repository) {
        this.scraper = scraper;
        this.repository = repository;
    }

    @Transactional
    public List<AlumniDto> searchAndSave(AlumniSearchRequest request) {
        List<AlumniDto> found = scraper.search(request);
        List<AlumniDto> result = new ArrayList<>();

        for (AlumniDto dto : found) {
            // if we already have this person, just refresh the row instead of adding a duplicate
            Alumni alumni = repository.findByNameAndUniversity(dto.name(), dto.university())
                    .orElseGet(Alumni::new);

            alumni.setName(dto.name());
            alumni.setCurrentRole(dto.currentRole());
            alumni.setUniversity(dto.university());
            alumni.setLocation(dto.location());
            alumni.setLinkedinHeadline(dto.linkedinHeadline());
            alumni.setPassoutYear(dto.passoutYear());

            result.add(toDto(repository.save(alumni)));
        }
        return result;
    }

    @Transactional(readOnly = true)
    public List<AlumniDto> getAll() {
        return repository.findAll().stream().map(this::toDto).toList();
    }

    private AlumniDto toDto(Alumni a) {
        return new AlumniDto(a.getName(), a.getCurrentRole(), a.getUniversity(),
                a.getLocation(), a.getLinkedinHeadline(), a.getPassoutYear());
    }
}
