package com.alumni.searcher.scraper;

import com.alumni.searcher.config.PhantomBusterProperties;
import com.alumni.searcher.dto.AlumniDto;
import com.alumni.searcher.dto.AlumniSearchRequest;
import com.alumni.searcher.exception.ScraperException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class PhantomBusterScraper implements ProfileScraper {

    private static final String API_KEY_HEADER = "X-Phantombuster-Key";

    private final RestTemplate restTemplate;
    private final PhantomBusterProperties props;
    private final ObjectMapper objectMapper;

    public PhantomBusterScraper(RestTemplate restTemplate, PhantomBusterProperties props, ObjectMapper objectMapper) {
        this.restTemplate = restTemplate;
        this.props = props;
        this.objectMapper = objectMapper;
    }

    @Override
    public List<AlumniDto> search(AlumniSearchRequest request) {
        checkConfig();

        String containerId = launchAgent(request);
        waitForAgentToFinish();
        JsonNode result = fetchResult(containerId);

        return parseProfiles(result, request);
    }

    private void checkConfig() {
        if (isBlank(props.getApiKey()) || isBlank(props.getAgentId())) {
            throw new ScraperException("PhantomBuster api key / agent id are not configured");
        }
    }

    private String launchAgent(AlumniSearchRequest request) {
        Map<String, Object> argument = new HashMap<>();
        argument.put("search", buildSearchQuery(request));
        argument.put("sessionCookie", props.getSessionCookie());
        argument.put("numberOfProfiles", props.getMaxProfiles());

        Map<String, Object> body = new HashMap<>();
        body.put("id", props.getAgentId());
        body.put("argument", argument);

        try {
            JsonNode response = restTemplate.exchange(
                    props.getBaseUrl() + "/agents/launch",
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers()),
                    JsonNode.class).getBody();

            if (response == null || !response.hasNonNull("containerId")) {
                throw new ScraperException("PhantomBuster did not return a container id");
            }
            return response.get("containerId").asText();
        } catch (RestClientException e) {
            throw new ScraperException("Could not launch the PhantomBuster agent: " + e.getMessage(), e);
        }
    }

    private void waitForAgentToFinish() {
        long deadline = System.currentTimeMillis() + props.getTimeoutSeconds() * 1000L;

        while (System.currentTimeMillis() < deadline) {
            try {
                Thread.sleep(props.getPollIntervalMs());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new ScraperException("Interrupted while waiting for PhantomBuster", e);
            }

            JsonNode output = get("/agents/fetch-output?id={id}", props.getAgentId());
            if (output != null && "finished".equals(output.path("status").asText())) {
                return;
            }
        }
        throw new ScraperException("PhantomBuster took too long to finish, try again in a bit");
    }

    private JsonNode fetchResult(String containerId) {
        JsonNode response = get("/containers/fetch-result-object?id={id}", containerId);
        if (response == null) {
            return objectMapper.createArrayNode();
        }

        // the result usually comes back as a json string inside "resultObject"
        JsonNode raw = response.has("resultObject") ? response.get("resultObject") : response;
        if (raw.isTextual()) {
            try {
                return objectMapper.readTree(raw.asText());
            } catch (JsonProcessingException e) {
                throw new ScraperException("Could not read the PhantomBuster result", e);
            }
        }
        return raw;
    }

    private JsonNode get(String path, String id) {
        try {
            return restTemplate.exchange(
                    props.getBaseUrl() + path,
                    HttpMethod.GET,
                    new HttpEntity<>(headers()),
                    JsonNode.class,
                    id).getBody();
        } catch (RestClientException e) {
            throw new ScraperException("PhantomBuster request failed: " + e.getMessage(), e);
        }
    }

    String buildSearchQuery(AlumniSearchRequest request) {
        StringBuilder query = new StringBuilder();
        query.append(request.getDesignation()).append(" ").append(request.getUniversity());
        if (request.getPassoutYear() != null) {
            query.append(" ").append(request.getPassoutYear());
        }
        return query.toString();
    }

    List<AlumniDto> parseProfiles(JsonNode result, AlumniSearchRequest request) {
        List<AlumniDto> alumni = new ArrayList<>();
        if (result == null || !result.isArray()) {
            return alumni;
        }

        for (JsonNode node : result) {
            String name = firstText(node, "fullName", "name");
            if (isBlank(name)) {
                continue;
            }
            String headline = firstText(node, "headline", "title", "job");
            String role = firstText(node, "currentRole", "job", "title");
            if (isBlank(role)) {
                role = request.getDesignation();
            }
            String location = firstText(node, "location");

            alumni.add(new AlumniDto(name, role, request.getUniversity(), location, headline, request.getPassoutYear()));
        }
        return alumni;
    }

    private String firstText(JsonNode node, String... keys) {
        for (String key : keys) {
            if (node.hasNonNull(key) && !node.get(key).asText().isBlank()) {
                return node.get(key).asText().trim();
            }
        }
        return null;
    }

    private HttpHeaders headers() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(API_KEY_HEADER, props.getApiKey());
        return headers;
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
