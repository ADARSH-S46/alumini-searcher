package com.alumni.searcher.controller;

import com.alumni.searcher.dto.AlumniDto;
import com.alumni.searcher.dto.AlumniSearchRequest;
import com.alumni.searcher.dto.ApiResponse;
import com.alumni.searcher.service.AlumniService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/alumni")
@Tag(name = "Alumni")
public class AlumniController {

    private final AlumniService alumniService;

    public AlumniController(AlumniService alumniService) {
        this.alumniService = alumniService;
    }

    @PostMapping("/search")
    @Operation(summary = "Search alumni on LinkedIn and save what we find")
    public ResponseEntity<ApiResponse<List<AlumniDto>>> search(@Valid @RequestBody AlumniSearchRequest request) {
        return ResponseEntity.ok(ApiResponse.success(alumniService.searchAndSave(request)));
    }

    @GetMapping("/all")
    @Operation(summary = "Get all alumni saved in the database")
    public ResponseEntity<ApiResponse<List<AlumniDto>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(alumniService.getAll()));
    }
}
