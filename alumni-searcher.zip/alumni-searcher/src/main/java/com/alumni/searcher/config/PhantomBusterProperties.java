package com.alumni.searcher.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "phantombuster")
public class PhantomBusterProperties {

    private String baseUrl;
    private String apiKey;
    private String agentId;
    private String sessionCookie;
    private int maxProfiles = 20;
    private long pollIntervalMs = 3000;
    private int timeoutSeconds = 120;

    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }

    public String getApiKey() { return apiKey; }
    public void setApiKey(String apiKey) { this.apiKey = apiKey; }

    public String getAgentId() { return agentId; }
    public void setAgentId(String agentId) { this.agentId = agentId; }

    public String getSessionCookie() { return sessionCookie; }
    public void setSessionCookie(String sessionCookie) { this.sessionCookie = sessionCookie; }

    public int getMaxProfiles() { return maxProfiles; }
    public void setMaxProfiles(int maxProfiles) { this.maxProfiles = maxProfiles; }

    public long getPollIntervalMs() { return pollIntervalMs; }
    public void setPollIntervalMs(long pollIntervalMs) { this.pollIntervalMs = pollIntervalMs; }

    public int getTimeoutSeconds() { return timeoutSeconds; }
    public void setTimeoutSeconds(int timeoutSeconds) { this.timeoutSeconds = timeoutSeconds; }
}
