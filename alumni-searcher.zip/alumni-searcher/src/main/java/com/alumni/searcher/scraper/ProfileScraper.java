package com.alumni.searcher.scraper;

import com.alumni.searcher.dto.AlumniDto;
import com.alumni.searcher.dto.AlumniSearchRequest;

import java.util.List;

/**
 * Anything that can go and find alumni profiles. Right now only PhantomBuster
 * implements it, but the service doesn't need to know that.
 */
public interface ProfileScraper {

    List<AlumniDto> search(AlumniSearchRequest request);
}
