package com.alumni.searcher.scraper;

import com.alumni.searcher.config.PhantomBusterProperties;
import com.alumni.searcher.dto.AlumniDto;
import com.alumni.searcher.dto.AlumniSearchRequest;
import com.alumni.searcher.exception.ScraperException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PhantomBusterScraperTest {

    private final ObjectMapper mapper = new ObjectMapper();
    private final PhantomBusterProperties props = new PhantomBusterProperties();
    private final PhantomBusterScraper scraper = new PhantomBusterScraper(new RestTemplate(), props, mapper);

    private final AlumniSearchRequest request = new AlumniSearchRequest("University of XYZ", "Software Engineer", 2020);

    @Test
    void buildSearchQuery_includesYearWhenGiven() {
        assertEquals("Software Engineer University of XYZ 2020", scraper.buildSearchQuery(request));
    }

    @Test
    void buildSearchQuery_skipsYearWhenMissing() {
        request.setPassoutYear(null);
        assertEquals("Software Engineer University of XYZ", scraper.buildSearchQuery(request));
    }

    @Test
    void parseProfiles_mapsFieldsFromPhantomBusterOutput() throws Exception {
        JsonNode json = mapper.readTree("""
                [
                  {"fullName": "John Doe", "headline": "Passionate Software Engineer at XYZ Corp", "location": "New York, NY"},
                  {"name": "Jane Smith", "title": "Data Scientist | AI Enthusiast", "location": "San Francisco, CA"}
                ]
                """);

        List<AlumniDto> result = scraper.parseProfiles(json, request);

        assertEquals(2, result.size());
        assertEquals("John Doe", result.get(0).name());
        assertEquals("New York, NY", result.get(0).location());
        assertEquals("University of XYZ", result.get(0).university());
        assertEquals("Jane Smith", result.get(1).name());
    }

    @Test
    void parseProfiles_skipsEntriesWithoutName() throws Exception {
        JsonNode json = mapper.readTree("[{\"headline\": \"no name here\"}]");
        assertTrue(scraper.parseProfiles(json, request).isEmpty());
    }

    @Test
    void parseProfiles_handlesNonArrayOutput() throws Exception {
        JsonNode json = mapper.readTree("{\"error\": \"nothing\"}");
        assertTrue(scraper.parseProfiles(json, request).isEmpty());
    }

    @Test
    void search_failsClearlyWhenNotConfigured() {
        assertThrows(ScraperException.class, () -> scraper.search(request));
    }
}
