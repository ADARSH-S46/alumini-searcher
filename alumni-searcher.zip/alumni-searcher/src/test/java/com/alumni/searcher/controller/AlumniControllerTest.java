package com.alumni.searcher.controller;

import com.alumni.searcher.dto.AlumniDto;
import com.alumni.searcher.exception.ScraperException;
import com.alumni.searcher.service.AlumniService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AlumniController.class)
class AlumniControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AlumniService alumniService;

    private final AlumniDto john = new AlumniDto("John Doe", "Software Engineer", "University of XYZ",
            "New York, NY", "Passionate Software Engineer at XYZ Corp", 2020);

    @Test
    void search_returnsSuccessWithData() throws Exception {
        when(alumniService.searchAndSave(any())).thenReturn(List.of(john));

        mockMvc.perform(post("/api/alumni/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"university\":\"University of XYZ\",\"designation\":\"Software Engineer\",\"passoutYear\":2020}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data[0].name").value("John Doe"))
                .andExpect(jsonPath("$.data[0].passoutYear").value(2020));
    }

    @Test
    void search_worksWithoutPassoutYear() throws Exception {
        when(alumniService.searchAndSave(any())).thenReturn(List.of(john));

        mockMvc.perform(post("/api/alumni/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"university\":\"University of XYZ\",\"designation\":\"Software Engineer\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void search_rejectsMissingUniversity() throws Exception {
        mockMvc.perform(post("/api/alumni/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"designation\":\"Software Engineer\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value("error"));
    }

    @Test
    void search_rejectsEmptyBody() throws Exception {
        mockMvc.perform(post("/api/alumni/search").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void search_returnsBadGatewayWhenPhantomBusterFails() throws Exception {
        when(alumniService.searchAndSave(any())).thenThrow(new ScraperException("PhantomBuster is down"));

        mockMvc.perform(post("/api/alumni/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"university\":\"University of XYZ\",\"designation\":\"Software Engineer\"}"))
                .andExpect(status().isBadGateway())
                .andExpect(jsonPath("$.message").value("PhantomBuster is down"));
    }

    @Test
    void getAll_returnsSavedProfiles() throws Exception {
        when(alumniService.getAll()).thenReturn(List.of(john));

        mockMvc.perform(get("/api/alumni/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data[0].location").value("New York, NY"));
    }
}
