package com.alumni.searcher.service;

import com.alumni.searcher.dto.AlumniDto;
import com.alumni.searcher.dto.AlumniSearchRequest;
import com.alumni.searcher.entity.Alumni;
import com.alumni.searcher.repository.AlumniRepository;
import com.alumni.searcher.scraper.ProfileScraper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AlumniServiceTest {

    @Mock
    private ProfileScraper scraper;

    @Mock
    private AlumniRepository repository;

    @InjectMocks
    private AlumniService service;

    private final AlumniSearchRequest request = new AlumniSearchRequest("University of XYZ", "Software Engineer", 2020);

    private AlumniDto johnDto() {
        return new AlumniDto("John Doe", "Software Engineer", "University of XYZ", "New York, NY",
                "Passionate Software Engineer at XYZ Corp", 2020);
    }

    @Test
    void searchAndSave_savesNewProfiles() {
        when(scraper.search(request)).thenReturn(List.of(johnDto()));
        when(repository.findByNameAndUniversity("John Doe", "University of XYZ")).thenReturn(Optional.empty());
        when(repository.save(any(Alumni.class))).thenAnswer(inv -> inv.getArgument(0));

        List<AlumniDto> result = service.searchAndSave(request);

        assertEquals(1, result.size());
        assertEquals("John Doe", result.get(0).name());
        verify(repository, times(1)).save(any(Alumni.class));
    }

    @Test
    void searchAndSave_updatesExistingProfileInsteadOfDuplicating() {
        Alumni existing = new Alumni();
        existing.setName("John Doe");
        existing.setUniversity("University of XYZ");
        existing.setLocation("Old City");

        when(scraper.search(request)).thenReturn(List.of(johnDto()));
        when(repository.findByNameAndUniversity("John Doe", "University of XYZ")).thenReturn(Optional.of(existing));
        when(repository.save(existing)).thenReturn(existing);

        List<AlumniDto> result = service.searchAndSave(request);

        assertEquals("New York, NY", result.get(0).location());
        verify(repository).save(existing);
    }

    @Test
    void searchAndSave_returnsEmptyListWhenNobodyFound() {
        when(scraper.search(request)).thenReturn(List.of());

        assertEquals(0, service.searchAndSave(request).size());
        verify(repository, times(0)).save(any(Alumni.class));
    }

    @Test
    void getAll_mapsEntitiesToDtos() {
        Alumni jane = new Alumni();
        jane.setName("Jane Smith");
        jane.setCurrentRole("Data Scientist");
        jane.setUniversity("University of XYZ");
        jane.setPassoutYear(2019);
        when(repository.findAll()).thenReturn(List.of(jane));

        List<AlumniDto> result = service.getAll();

        assertEquals(1, result.size());
        assertEquals("Data Scientist", result.get(0).currentRole());
        assertEquals(2019, result.get(0).passoutYear());
    }
}
